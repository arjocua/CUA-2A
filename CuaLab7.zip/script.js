document.addEventListener('DOMContentLoaded', function () {
  const nameEl = document.getElementById('name');
  const priceEl = document.getElementById('price');
  const stockEl = document.getElementById('stock');
  const addBtn = document.getElementById('addBtn');
  const tbody = document.querySelector('#inventory tbody');

  function updateButtonState() {
    const canAdd = nameEl.value.trim() !== '' && priceEl.value.trim() !== '' && stockEl.value.trim() !== '';
    addBtn.disabled = !canAdd;
  }

  nameEl.addEventListener('input', updateButtonState);
  priceEl.addEventListener('input', updateButtonState);
  stockEl.addEventListener('input', updateButtonState);

  updateButtonState();

  addBtn.addEventListener('click', function () {
    const name = nameEl.value.trim();
    const price = parseFloat(priceEl.value);
    const stock = parseInt(stockEl.value, 10);

    if (name === '' || isNaN(price) || isNaN(stock)) return;

    let nextId = 1;
    const rows = tbody.querySelectorAll('tr');
    if (rows.length > 0) {
      const lastId = parseInt(rows[rows.length - 1].firstElementChild.textContent, 10);
      nextId = lastId + 1;
    }

    const tr = document.createElement('tr');
    const idTd = document.createElement('td');
    idTd.textContent = nextId;
    const nameTd = document.createElement('td');
    nameTd.textContent = name;
    const priceTd = document.createElement('td');
    priceTd.textContent = '$' + price.toFixed(2);
    const stockTd = document.createElement('td');
    stockTd.textContent = stock;

    tr.appendChild(idTd);
    tr.appendChild(nameTd);
    tr.appendChild(priceTd);
    tr.appendChild(stockTd);

    tbody.appendChild(tr);

    nameEl.value = '';
    priceEl.value = '';
    stockEl.value = '';
    updateButtonState();
  });

});
