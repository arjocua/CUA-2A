document.addEventListener('DOMContentLoaded', function () {

  const InventoryManager = {
    tbody: document.querySelector('#inventory tbody'),
    nameEl: document.getElementById('name'),
    priceEl: document.getElementById('price'),
    stockEl: document.getElementById('stock'),
    addBtn: document.getElementById('addBtn'),

    getNextId() {
      const rows = this.tbody.querySelectorAll('tr');
      if (rows.length === 0) return 1;
      const lastId = parseInt(rows[rows.length - 1].firstElementChild.textContent, 10);
      return lastId + 1;
    },

    renderProduct(product) {
      const tr = document.createElement('tr');

      const idTd = document.createElement('td');
      idTd.textContent = product.id;

      const nameTd = document.createElement('td');
      nameTd.textContent = product.name;

      const priceTd = document.createElement('td');
      priceTd.textContent = '$' + product.price.toFixed(2);

      const stockTd = document.createElement('td');
      stockTd.textContent = product.stock;

      tr.appendChild(idTd);
      tr.appendChild(nameTd);
      tr.appendChild(priceTd);
      tr.appendChild(stockTd);

      this.tbody.appendChild(tr);
    },

    addProduct(newProduct) {
      const product = {
        id:    newProduct.id ?? this.getNextId(),
        name:  newProduct.name,
        price: parseFloat(newProduct.price),
        stock: parseInt(newProduct.stock, 10),
      };

      if (!product.name || isNaN(product.price) || isNaN(product.stock)) {
        console.warn('addProduct: invalid product data', newProduct);
        return;
      }

      this.renderProduct(product);
    },

    updateButtonState() {
      const canAdd =
        this.nameEl.value.trim()  !== '' &&
        this.priceEl.value.trim() !== '' &&
        this.stockEl.value.trim() !== '';
      this.addBtn.disabled = !canAdd;
    },

    clearInputs() {
      this.nameEl.value  = '';
      this.priceEl.value = '';
      this.stockEl.value = '';
      this.updateButtonState();
    },

    bindEvents() {
      this.nameEl.addEventListener('input',  () => this.updateButtonState());
      this.priceEl.addEventListener('input', () => this.updateButtonState());
      this.stockEl.addEventListener('input', () => this.updateButtonState());

      this.addBtn.addEventListener('click', () => {
        const newProduct = {
          name:  this.nameEl.value.trim(),
          price: parseFloat(this.priceEl.value),
          stock: parseInt(this.stockEl.value, 10),
        };

        this.addProduct(newProduct);
        this.clearInputs();
      });
    },

    init() {
      this.updateButtonState();
      this.bindEvents();
    },
  };

  InventoryManager.init();

});